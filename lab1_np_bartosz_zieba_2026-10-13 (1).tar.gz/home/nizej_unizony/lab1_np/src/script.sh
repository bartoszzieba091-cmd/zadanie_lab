#!/bin/bash
# Prosty skrypt powitalny

echo "Witaj w Linuxie!"
echo "Data i czas: $(date)"
echo "Użytkownik: $USER"
echo "Uruchomiono z katalogu: $(pwd)"
echo "System: $(uname -o), jądro: $(uname -r)"
